const fecha = document.querySelector('#fecha');
const formulario = document.querySelector('#formulario');
const input = document.querySelector('#input');
const lista = document.querySelector('#lista');
let tareas = JSON.parse(localStorage.getItem('tareas')) || [];

const FECHA = new Date();
fecha.innerHTML = FECHA.toLocaleDateString('es-MX', { weekday: 'long', month: 'short', day: 'numeric' });

document.querySelector('#enter').addEventListener('click', agregarTarea);

function agregarTarea() {
    const tareaNombre = input.value.trim();
    
    if (tareaNombre) {
        const nuevaTarea = {
            id: Date.now(),
            nombre: tareaNombre,
            completada: false
        };
        tareas.push(nuevaTarea);
        localStorage.setItem('tareas', JSON.stringify(tareas));
        input.value = '';
        mostrarTareas();
    } else {
        alert("Por favor, ingresa una tarea."); 
    }
}

function mostrarTareas() {
    lista.innerHTML = '';
    tareas.forEach(tarea => {
        const elemento = document.createElement('li');
        elemento.innerHTML = `
            <img class="viñeta" src="img/en_fila.png" alt="Viñeta">
            <span class="${tarea.completada ? 'completada' : ''}">${tarea.nombre}</span>
            <button class="eliminar" data-id="${tarea.id}">Eliminar</button>
            <button class="completar" data-id="${tarea.id}">${tarea.completada ? 'Desmarcar' : 'Completar'}</button>
        `;
        lista.appendChild(elemento);
    });
}

function eliminarTarea(id) {
    tareas = tareas.filter(tarea => tarea.id !== parseInt(id));
    localStorage.setItem('tareas', JSON.stringify(tareas));
    mostrarTareas();
}

function completarTarea(id) {
    tareas = tareas.map(tarea => {
        if (tarea.id === parseInt(id)) {
            tarea.completada = !tarea.completada;
        }
        return tarea;
    });
    localStorage.setItem('tareas', JSON.stringify(tareas));
    mostrarTareas();
}

lista.addEventListener('click', function (event) {
    if (event.target.classList.contains('eliminar')) {
        eliminarTarea(event.target.dataset.id);
    } else if (event.target.classList.contains('completar')) {
        completarTarea(event.target.dataset.id);
    }
});

mostrarTareas();
